# QC-to-TROA Hanger Migrator

Standalone server-admin migration tool for copying eligible Quantum Hangar `.sbc` files into the TROA-Hanger player-storage layout.

## Safety Rules

- The tool is **preview-only by default**.
- It never edits, moves, or deletes Quantum Hangar files.
- It copies files only when run with `--copy`.
- It backs up an existing `TROA-HangerCatalog.xml` before writing changes.
- It skips a grid if it cannot identify exactly one owner Steam ID.
- It creates `QC-to-TROA-migration-report.txt` in the TROA data folder after a copy run.

## Before You Start

1. Stop Torch and back up your world, Quantum Hangar folder, and TROA-Hanger data folder.
2. Install and start TROA-Hanger once so its data root exists.
3. Identify the old Quantum Hangar storage folder that contains player `.sbc` files.
4. Run the preview first. Review every `SKIPPED` line before copying.

## Commands

From Command Prompt or PowerShell:

```text
QC-to-TROA-Hanger-Migrator.exe --source "C:\OldQuantumHangar" --target "C:\TROA-HangerData"
```

The command above performs a preview only.

When the preview is correct, run the real copy:

```text
QC-to-TROA-Hanger-Migrator.exe --source "C:\OldQuantumHangar" --target "C:\TROA-HangerData" --copy
```

## Owner Recognition

The tool recognizes a player when exactly one Steam ID64 (`7656...`) appears in the source file path or file name. This covers normal layouts such as:

```text
QuantumHangar\76561198000000000\MyShip.sbc
QuantumHangar\Players\P76561198000000000\MyShip.sbc
```

If a QC server used player names or another folder scheme, provide a CSV mapping:

```text
PlayerFolderName,76561198000000000
AnotherPlayerFolder,76561198000000001
```

Then run:

```text
QC-to-TROA-Hanger-Migrator.exe --source "C:\OldQuantumHangar" --target "C:\TROA-HangerData" --mapping "C:\qc-player-mapping.csv" --copy
```

The first value matches part of a source file path. The second value must be that player's Steam ID64.

## Output

Migrated grids are copied to:

```text
TROA-HangerData\PlayersHangers\<SteamID>\
```

Compatible player records are added to:

```text
TROA-HangerData\TROA-HangerCatalog.xml
```

After restarting Torch, players can use `!hanger list` and `!hanger load <number>`.

## Not Migrated

This first standalone tool imports player `.sbc` grid files only. It does not migrate old Quantum Hangar market offers, bids, cross-server data, or Keen Grid Storage identifiers. Those records are not safe to recreate automatically without inspecting the specific QC storage version.
